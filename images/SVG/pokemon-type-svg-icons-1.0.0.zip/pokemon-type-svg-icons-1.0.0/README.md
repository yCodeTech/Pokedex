## Pokemon Type SVG Icons

Very simple set of SVG icons for Pokemon types for any use.

See them in action [here](https://duiker101.github.io/pokemon-type-svg-icons/index.html): 

[Original source](https://dribbble.com/shots/4862612-Pokedex-iOS-app)
